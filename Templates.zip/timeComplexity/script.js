$(document).ready(function () {
    $("#btn1").click(function () {
        prompt("The time complexity of the following code is: O(" + analyzeTimeComplexity + ")");
    });
});

function analyzeTimeComplexity() {
    var javaCode = document.getElementById('codeInput').value;

    try {
        // Assume the Big-O library can handle your Java code
        const timeComplexity = BigO(codeInput);

        alert(`Estimated Time Complexity: O(${timeComplexity})`);
    } catch (error) {
        alert('Error analyzing time complexity. Please check the syntax.');
    }
}
function BigO(){
    if(javaCode.length < 0 | javaCode.length < 1){
        return 1;
    }
    else if(javaCode.length <= n){
        return n;
    }
    else if(javaCode.length <= n){
        return n;
    }

}

